# MVG Research Evaluation License v1.0

Copyright Meridian Verity Group.

This public synthetic corpus is provided for non-production research, evaluation, citation, internal review, security review, procurement review, and architecture-fit discussion only.

It does not grant a patent license, production deployment license, trademark license, commercial implementation right, right to implement any issued claim, production authorization credential, or vendor certification.

Commercial, production, platform, cloud, accelerator, embedded, runtime, or enterprise integrations require a separate written agreement with the appropriate rights holder.
