# Dual-Gate Conformance Corpus for Attested Agentic AI

MVG-DGER-CORPUS-2026-001 v1.0.0

Public synthetic conformance corpus for dual-gate evidence rails: deny-before-inference and permit-before-commit decision semantics.

This corpus is public-safe, vendor-neutral, synthetic-only, and non-authorizing. It contains no customer data, no secrets, no production credentials, no private vendor fields, and no production authorization credential. It is not a production deployment package, not a vendor-certified integration, and not a patent license.

## Contents

- schemas/ — JSON schemas for ActionProposal, VerifierPosture, PolicyProfile, GateDecision, DecisionReceipt, and EvidencePack.
- vectors/ — 29 public synthetic vectors covering ACCEPT, HOLD, and FAIL.
- reference_receipts/ — DecisionReceipt reference objects.
- evidence_packs/ — EvidencePack reference objects.
- reference_outputs/ — conformance matrix and summary.
- EVIDENCE_PASSPORT.md — forwardable public evidence passport.

## Decision coverage

- ACCEPT: 7
- HOLD: 7
- FAIL: 15

## Boundary

No production use. No patent license. No production deployment validation. No customer-specific assurance. No vendor endorsement, certification, or integration claim.
