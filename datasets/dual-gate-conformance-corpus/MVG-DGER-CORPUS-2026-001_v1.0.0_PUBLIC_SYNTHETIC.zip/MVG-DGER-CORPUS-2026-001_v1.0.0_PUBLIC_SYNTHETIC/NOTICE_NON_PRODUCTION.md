# Non-production notice

This corpus is synthetic, public-safe, and non-authorizing. It contains no customer data, no production secrets, no private vendor fields, no production credentials, and no production authorization credential.

The DecisionReceipt and EvidencePack objects are digest-bound public review artifacts only. They are not production authorization tokens, signed envelopes, derived capabilities, or deployment credentials.
