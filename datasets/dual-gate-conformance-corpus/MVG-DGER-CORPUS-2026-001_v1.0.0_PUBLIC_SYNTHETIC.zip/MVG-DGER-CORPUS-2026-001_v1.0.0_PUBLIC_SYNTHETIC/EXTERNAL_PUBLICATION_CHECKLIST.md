# External publication checklist

- Confirm no vendor-specific terms, private fields, customer data, secrets, production credentials, or production claims.
- Confirm license / no-patent-license notice.
- Confirm related identifier to technical report DOI.
- Confirm corpus ZIP, manifest, and SHA256SUMS.
- Confirm no vendor-specific private kit material is included.
