# V407 release notes

Initial public synthetic conformance corpus. 29 vectors: 7 ACCEPT, 7 HOLD, 15 FAIL.
